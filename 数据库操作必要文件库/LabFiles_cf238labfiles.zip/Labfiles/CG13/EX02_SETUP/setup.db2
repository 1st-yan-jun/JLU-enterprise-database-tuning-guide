--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X2DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X2DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13X2DB;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING XML TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE xmlproduct (
  Pid         VARCHAR(10) NOT NULL PRIMARY KEY,
  Description XML
);
--
CREATE TABLE xmlcustomer (
  Cid        BIGINT NOT NULL PRIMARY KEY,
  Info       XML
);
-- 
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING XML TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "xmlcustomer.data" OF IXF MESSAGES "xmlcustomer.err" REPLACE INTO xmlcustomer;
IMPORT FROM "xmlproduct.data" OF IXF MESSAGES "xmlproduct.err" REPLACE INTO xmlproduct;

CONNECT RESET ; 



