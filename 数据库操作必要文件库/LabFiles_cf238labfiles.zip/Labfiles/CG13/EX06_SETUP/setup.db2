create database CG13X6DB using codeset utf-8 territory us;
create database NONUTF8;
connect to CG13X6DB;
create tablespace smsts1 managed by system using ('smsts');
create table t1(doc varchar(1000)) in smsts1;
create table t2(doc clob(1k)) in smsts1;
create table t3(doc xml) in smsts1;
connect reset;