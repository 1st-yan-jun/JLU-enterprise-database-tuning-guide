--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X9DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X9DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13X9DB;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~     CREATING TABLES     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

create table xsr.employee(c xml );
create table xsr.order(c xml);
create table xsr.city(c xml);

CONNECT RESET ;