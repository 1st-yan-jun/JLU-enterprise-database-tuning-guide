--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X3DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X3DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13X3DB;

--

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING XML TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE xmlproduct (
  Pid         VARCHAR(10) NOT NULL PRIMARY KEY,
  Description XML
);
--

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING SQL TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE sqlproduct (
  Pid         VARCHAR(10) NOT NULL PRIMARY KEY,
  Name        VARCHAR(128),
  Details     VARCHAR(255),
  Price       DECIMAL(30,2),
  Weight      DECIMAL(10,2),
  Category    VARCHAR(128),
  Brand       VARCHAR(128),
  Size        VARCHAR(128),
  Description CLOB(32K)
);
--

CREATE TABLE sqlimages (
Pid         VARCHAR(10) NOT NULL,
Type        VARCHAR(32),
Alias       VARCHAR(32),
Location    VARCHAR(128)
);


echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING XML TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "xmlproduct.data" OF IXF MESSAGES "xmlproduct.err" REPLACE INTO xmlproduct;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING SQL TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "sqlproduct.data" OF IXF MESSAGES "sqlproduct.err" REPLACE INTO sqlproduct;

CONNECT RESET ;



