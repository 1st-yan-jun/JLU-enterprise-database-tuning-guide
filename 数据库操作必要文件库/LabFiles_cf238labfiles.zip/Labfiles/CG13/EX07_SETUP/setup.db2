--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X7DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X7DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13X7DB;

--

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING XML TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE xmlcustomer (
  Cid        BIGINT NOT NULL PRIMARY KEY,
  Info       XML
);
-- 
CREATE TABLE xmlporder (
  POid   BIGINT NOT NULL PRIMARY KEY,
  POdate DATE,
  POrder XML
);

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING XML TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "xmlporder.data" OF IXF MESSAGES "xmlporder.err" REPLACE INTO xmlporder;
IMPORT FROM "xmlcustomer.data" OF IXF MESSAGES "xmlcustomer.err" REPLACE INTO xmlcustomer;

CONNECT RESET ;


