--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X8DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X8DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CONNECT TO CG13X8DB;

--CREATE TABLE XMLCUSTOMER 

CREATE TABLE XMLCUSTOMER (
    Cid        BIGINT NOT NULL,
    Info       XML
  );


--Inserting 1000 records 

insert into XMLCUSTOMER values (0, xmlparse(document '
<customerinfo>
    <id>0</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (1, xmlparse(document '
<customerinfo>
    <id>1</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (2, xmlparse(document '
<customerinfo>
    <id>2</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (3, xmlparse(document '
<customerinfo>
    <id>3</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (4, xmlparse(document '
<customerinfo>
    <id>4</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (5, xmlparse(document '
<customerinfo>
    <id>5</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (6, xmlparse(document '
<customerinfo>
    <id>6</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (7, xmlparse(document '
<customerinfo>
    <id>7</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (8, xmlparse(document '
<customerinfo>
    <id>8</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (9, xmlparse(document '
<customerinfo>
    <id>9</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (10, xmlparse(document '
<customerinfo>
    <id>10</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (11, xmlparse(document '
<customerinfo>
    <id>11</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (12, xmlparse(document '
<customerinfo>
    <id>12</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (13, xmlparse(document '
<customerinfo>
    <id>13</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (14, xmlparse(document '
<customerinfo>
    <id>14</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (15, xmlparse(document '
<customerinfo>
    <id>15</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (16, xmlparse(document '
<customerinfo>
    <id>16</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (17, xmlparse(document '
<customerinfo>
    <id>17</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (18, xmlparse(document '
<customerinfo>
    <id>18</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (19, xmlparse(document '
<customerinfo>
    <id>19</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (20, xmlparse(document '
<customerinfo>
    <id>20</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (21, xmlparse(document '
<customerinfo>
    <id>21</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (22, xmlparse(document '
<customerinfo>
    <id>22</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (23, xmlparse(document '
<customerinfo>
    <id>23</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (24, xmlparse(document '
<customerinfo>
    <id>24</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (25, xmlparse(document '
<customerinfo>
    <id>25</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (26, xmlparse(document '
<customerinfo>
    <id>26</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (27, xmlparse(document '
<customerinfo>
    <id>27</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (28, xmlparse(document '
<customerinfo>
    <id>28</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (29, xmlparse(document '
<customerinfo>
    <id>29</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (30, xmlparse(document '
<customerinfo>
    <id>30</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (31, xmlparse(document '
<customerinfo>
    <id>31</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (32, xmlparse(document '
<customerinfo>
    <id>32</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (33, xmlparse(document '
<customerinfo>
    <id>33</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (34, xmlparse(document '
<customerinfo>
    <id>34</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (35, xmlparse(document '
<customerinfo>
    <id>35</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (36, xmlparse(document '
<customerinfo>
    <id>36</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (37, xmlparse(document '
<customerinfo>
    <id>37</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (38, xmlparse(document '
<customerinfo>
    <id>38</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (39, xmlparse(document '
<customerinfo>
    <id>39</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (40, xmlparse(document '
<customerinfo>
    <id>40</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (41, xmlparse(document '
<customerinfo>
    <id>41</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (42, xmlparse(document '
<customerinfo>
    <id>42</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (43, xmlparse(document '
<customerinfo>
    <id>43</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (44, xmlparse(document '
<customerinfo>
    <id>44</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (45, xmlparse(document '
<customerinfo>
    <id>45</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (46, xmlparse(document '
<customerinfo>
    <id>46</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (47, xmlparse(document '
<customerinfo>
    <id>47</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (48, xmlparse(document '
<customerinfo>
    <id>48</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (49, xmlparse(document '
<customerinfo>
    <id>49</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (50, xmlparse(document '
<customerinfo>
    <id>50</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (51, xmlparse(document '
<customerinfo>
    <id>51</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (52, xmlparse(document '
<customerinfo>
    <id>52</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (53, xmlparse(document '
<customerinfo>
    <id>53</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (54, xmlparse(document '
<customerinfo>
    <id>54</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (55, xmlparse(document '
<customerinfo>
    <id>55</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (56, xmlparse(document '
<customerinfo>
    <id>56</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (57, xmlparse(document '
<customerinfo>
    <id>57</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (58, xmlparse(document '
<customerinfo>
    <id>58</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (59, xmlparse(document '
<customerinfo>
    <id>59</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (60, xmlparse(document '
<customerinfo>
    <id>60</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (61, xmlparse(document '
<customerinfo>
    <id>61</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (62, xmlparse(document '
<customerinfo>
    <id>62</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (63, xmlparse(document '
<customerinfo>
    <id>63</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (64, xmlparse(document '
<customerinfo>
    <id>64</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (65, xmlparse(document '
<customerinfo>
    <id>65</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (66, xmlparse(document '
<customerinfo>
    <id>66</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (67, xmlparse(document '
<customerinfo>
    <id>67</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (68, xmlparse(document '
<customerinfo>
    <id>68</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (69, xmlparse(document '
<customerinfo>
    <id>69</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (70, xmlparse(document '
<customerinfo>
    <id>70</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (71, xmlparse(document '
<customerinfo>
    <id>71</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (72, xmlparse(document '
<customerinfo>
    <id>72</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (73, xmlparse(document '
<customerinfo>
    <id>73</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (74, xmlparse(document '
<customerinfo>
    <id>74</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (75, xmlparse(document '
<customerinfo>
    <id>75</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (76, xmlparse(document '
<customerinfo>
    <id>76</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (77, xmlparse(document '
<customerinfo>
    <id>77</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (78, xmlparse(document '
<customerinfo>
    <id>78</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (79, xmlparse(document '
<customerinfo>
    <id>79</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (80, xmlparse(document '
<customerinfo>
    <id>80</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (81, xmlparse(document '
<customerinfo>
    <id>81</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (82, xmlparse(document '
<customerinfo>
    <id>82</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (83, xmlparse(document '
<customerinfo>
    <id>83</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (84, xmlparse(document '
<customerinfo>
    <id>84</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (85, xmlparse(document '
<customerinfo>
    <id>85</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (86, xmlparse(document '
<customerinfo>
    <id>86</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (87, xmlparse(document '
<customerinfo>
    <id>87</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (88, xmlparse(document '
<customerinfo>
    <id>88</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (89, xmlparse(document '
<customerinfo>
    <id>89</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (90, xmlparse(document '
<customerinfo>
    <id>90</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (91, xmlparse(document '
<customerinfo>
    <id>91</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (92, xmlparse(document '
<customerinfo>
    <id>92</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (93, xmlparse(document '
<customerinfo>
    <id>93</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (94, xmlparse(document '
<customerinfo>
    <id>94</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (95, xmlparse(document '
<customerinfo>
    <id>95</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (96, xmlparse(document '
<customerinfo>
    <id>96</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (97, xmlparse(document '
<customerinfo>
    <id>97</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (98, xmlparse(document '
<customerinfo>
    <id>98</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (99, xmlparse(document '
<customerinfo>
    <id>99</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (100, xmlparse(document '
<customerinfo>
    <id>100</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (101, xmlparse(document '
<customerinfo>
    <id>101</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (102, xmlparse(document '
<customerinfo>
    <id>102</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (103, xmlparse(document '
<customerinfo>
    <id>103</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (104, xmlparse(document '
<customerinfo>
    <id>104</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (105, xmlparse(document '
<customerinfo>
    <id>105</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (106, xmlparse(document '
<customerinfo>
    <id>106</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (107, xmlparse(document '
<customerinfo>
    <id>107</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (108, xmlparse(document '
<customerinfo>
    <id>108</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (109, xmlparse(document '
<customerinfo>
    <id>109</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (110, xmlparse(document '
<customerinfo>
    <id>110</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (111, xmlparse(document '
<customerinfo>
    <id>111</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (112, xmlparse(document '
<customerinfo>
    <id>112</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (113, xmlparse(document '
<customerinfo>
    <id>113</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (114, xmlparse(document '
<customerinfo>
    <id>114</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (115, xmlparse(document '
<customerinfo>
    <id>115</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (116, xmlparse(document '
<customerinfo>
    <id>116</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (117, xmlparse(document '
<customerinfo>
    <id>117</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (118, xmlparse(document '
<customerinfo>
    <id>118</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (119, xmlparse(document '
<customerinfo>
    <id>119</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (120, xmlparse(document '
<customerinfo>
    <id>120</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (121, xmlparse(document '
<customerinfo>
    <id>121</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (122, xmlparse(document '
<customerinfo>
    <id>122</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (123, xmlparse(document '
<customerinfo>
    <id>123</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (124, xmlparse(document '
<customerinfo>
    <id>124</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (125, xmlparse(document '
<customerinfo>
    <id>125</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (126, xmlparse(document '
<customerinfo>
    <id>126</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (127, xmlparse(document '
<customerinfo>
    <id>127</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (128, xmlparse(document '
<customerinfo>
    <id>128</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (129, xmlparse(document '
<customerinfo>
    <id>129</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (130, xmlparse(document '
<customerinfo>
    <id>130</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (131, xmlparse(document '
<customerinfo>
    <id>131</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (132, xmlparse(document '
<customerinfo>
    <id>132</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (133, xmlparse(document '
<customerinfo>
    <id>133</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (134, xmlparse(document '
<customerinfo>
    <id>134</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (135, xmlparse(document '
<customerinfo>
    <id>135</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (136, xmlparse(document '
<customerinfo>
    <id>136</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (137, xmlparse(document '
<customerinfo>
    <id>137</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (138, xmlparse(document '
<customerinfo>
    <id>138</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (139, xmlparse(document '
<customerinfo>
    <id>139</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (140, xmlparse(document '
<customerinfo>
    <id>140</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (141, xmlparse(document '
<customerinfo>
    <id>141</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (142, xmlparse(document '
<customerinfo>
    <id>142</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (143, xmlparse(document '
<customerinfo>
    <id>143</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (144, xmlparse(document '
<customerinfo>
    <id>144</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (145, xmlparse(document '
<customerinfo>
    <id>145</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (146, xmlparse(document '
<customerinfo>
    <id>146</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (147, xmlparse(document '
<customerinfo>
    <id>147</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (148, xmlparse(document '
<customerinfo>
    <id>148</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (149, xmlparse(document '
<customerinfo>
    <id>149</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (150, xmlparse(document '
<customerinfo>
    <id>150</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (151, xmlparse(document '
<customerinfo>
    <id>151</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (152, xmlparse(document '
<customerinfo>
    <id>152</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (153, xmlparse(document '
<customerinfo>
    <id>153</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (154, xmlparse(document '
<customerinfo>
    <id>154</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (155, xmlparse(document '
<customerinfo>
    <id>155</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (156, xmlparse(document '
<customerinfo>
    <id>156</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (157, xmlparse(document '
<customerinfo>
    <id>157</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (158, xmlparse(document '
<customerinfo>
    <id>158</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (159, xmlparse(document '
<customerinfo>
    <id>159</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (160, xmlparse(document '
<customerinfo>
    <id>160</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (161, xmlparse(document '
<customerinfo>
    <id>161</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (162, xmlparse(document '
<customerinfo>
    <id>162</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (163, xmlparse(document '
<customerinfo>
    <id>163</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (164, xmlparse(document '
<customerinfo>
    <id>164</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (165, xmlparse(document '
<customerinfo>
    <id>165</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (166, xmlparse(document '
<customerinfo>
    <id>166</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (167, xmlparse(document '
<customerinfo>
    <id>167</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (168, xmlparse(document '
<customerinfo>
    <id>168</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (169, xmlparse(document '
<customerinfo>
    <id>169</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (170, xmlparse(document '
<customerinfo>
    <id>170</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (171, xmlparse(document '
<customerinfo>
    <id>171</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (172, xmlparse(document '
<customerinfo>
    <id>172</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (173, xmlparse(document '
<customerinfo>
    <id>173</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (174, xmlparse(document '
<customerinfo>
    <id>174</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (175, xmlparse(document '
<customerinfo>
    <id>175</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (176, xmlparse(document '
<customerinfo>
    <id>176</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (177, xmlparse(document '
<customerinfo>
    <id>177</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (178, xmlparse(document '
<customerinfo>
    <id>178</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (179, xmlparse(document '
<customerinfo>
    <id>179</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (180, xmlparse(document '
<customerinfo>
    <id>180</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (181, xmlparse(document '
<customerinfo>
    <id>181</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (182, xmlparse(document '
<customerinfo>
    <id>182</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (183, xmlparse(document '
<customerinfo>
    <id>183</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (184, xmlparse(document '
<customerinfo>
    <id>184</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (185, xmlparse(document '
<customerinfo>
    <id>185</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (186, xmlparse(document '
<customerinfo>
    <id>186</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (187, xmlparse(document '
<customerinfo>
    <id>187</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (188, xmlparse(document '
<customerinfo>
    <id>188</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (189, xmlparse(document '
<customerinfo>
    <id>189</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (190, xmlparse(document '
<customerinfo>
    <id>190</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (191, xmlparse(document '
<customerinfo>
    <id>191</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (192, xmlparse(document '
<customerinfo>
    <id>192</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (193, xmlparse(document '
<customerinfo>
    <id>193</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (194, xmlparse(document '
<customerinfo>
    <id>194</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (195, xmlparse(document '
<customerinfo>
    <id>195</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (196, xmlparse(document '
<customerinfo>
    <id>196</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (197, xmlparse(document '
<customerinfo>
    <id>197</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (198, xmlparse(document '
<customerinfo>
    <id>198</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (199, xmlparse(document '
<customerinfo>
    <id>199</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (200, xmlparse(document '
<customerinfo>
    <id>200</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (201, xmlparse(document '
<customerinfo>
    <id>201</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (202, xmlparse(document '
<customerinfo>
    <id>202</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (203, xmlparse(document '
<customerinfo>
    <id>203</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (204, xmlparse(document '
<customerinfo>
    <id>204</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (205, xmlparse(document '
<customerinfo>
    <id>205</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (206, xmlparse(document '
<customerinfo>
    <id>206</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (207, xmlparse(document '
<customerinfo>
    <id>207</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (208, xmlparse(document '
<customerinfo>
    <id>208</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (209, xmlparse(document '
<customerinfo>
    <id>209</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (210, xmlparse(document '
<customerinfo>
    <id>210</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (211, xmlparse(document '
<customerinfo>
    <id>211</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (212, xmlparse(document '
<customerinfo>
    <id>212</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (213, xmlparse(document '
<customerinfo>
    <id>213</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (214, xmlparse(document '
<customerinfo>
    <id>214</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (215, xmlparse(document '
<customerinfo>
    <id>215</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (216, xmlparse(document '
<customerinfo>
    <id>216</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (217, xmlparse(document '
<customerinfo>
    <id>217</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (218, xmlparse(document '
<customerinfo>
    <id>218</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (219, xmlparse(document '
<customerinfo>
    <id>219</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (220, xmlparse(document '
<customerinfo>
    <id>220</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (221, xmlparse(document '
<customerinfo>
    <id>221</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (222, xmlparse(document '
<customerinfo>
    <id>222</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (223, xmlparse(document '
<customerinfo>
    <id>223</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (224, xmlparse(document '
<customerinfo>
    <id>224</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (225, xmlparse(document '
<customerinfo>
    <id>225</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (226, xmlparse(document '
<customerinfo>
    <id>226</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (227, xmlparse(document '
<customerinfo>
    <id>227</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (228, xmlparse(document '
<customerinfo>
    <id>228</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (229, xmlparse(document '
<customerinfo>
    <id>229</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (230, xmlparse(document '
<customerinfo>
    <id>230</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (231, xmlparse(document '
<customerinfo>
    <id>231</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (232, xmlparse(document '
<customerinfo>
    <id>232</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (233, xmlparse(document '
<customerinfo>
    <id>233</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (234, xmlparse(document '
<customerinfo>
    <id>234</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (235, xmlparse(document '
<customerinfo>
    <id>235</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (236, xmlparse(document '
<customerinfo>
    <id>236</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (237, xmlparse(document '
<customerinfo>
    <id>237</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (238, xmlparse(document '
<customerinfo>
    <id>238</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (239, xmlparse(document '
<customerinfo>
    <id>239</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (240, xmlparse(document '
<customerinfo>
    <id>240</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (241, xmlparse(document '
<customerinfo>
    <id>241</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (242, xmlparse(document '
<customerinfo>
    <id>242</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (243, xmlparse(document '
<customerinfo>
    <id>243</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (244, xmlparse(document '
<customerinfo>
    <id>244</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (245, xmlparse(document '
<customerinfo>
    <id>245</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (246, xmlparse(document '
<customerinfo>
    <id>246</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (247, xmlparse(document '
<customerinfo>
    <id>247</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (248, xmlparse(document '
<customerinfo>
    <id>248</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (249, xmlparse(document '
<customerinfo>
    <id>249</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (250, xmlparse(document '
<customerinfo>
    <id>250</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (251, xmlparse(document '
<customerinfo>
    <id>251</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (252, xmlparse(document '
<customerinfo>
    <id>252</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (253, xmlparse(document '
<customerinfo>
    <id>253</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (254, xmlparse(document '
<customerinfo>
    <id>254</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (255, xmlparse(document '
<customerinfo>
    <id>255</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (256, xmlparse(document '
<customerinfo>
    <id>256</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (257, xmlparse(document '
<customerinfo>
    <id>257</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (258, xmlparse(document '
<customerinfo>
    <id>258</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (259, xmlparse(document '
<customerinfo>
    <id>259</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (260, xmlparse(document '
<customerinfo>
    <id>260</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (261, xmlparse(document '
<customerinfo>
    <id>261</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (262, xmlparse(document '
<customerinfo>
    <id>262</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (263, xmlparse(document '
<customerinfo>
    <id>263</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (264, xmlparse(document '
<customerinfo>
    <id>264</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (265, xmlparse(document '
<customerinfo>
    <id>265</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (266, xmlparse(document '
<customerinfo>
    <id>266</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (267, xmlparse(document '
<customerinfo>
    <id>267</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (268, xmlparse(document '
<customerinfo>
    <id>268</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (269, xmlparse(document '
<customerinfo>
    <id>269</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (270, xmlparse(document '
<customerinfo>
    <id>270</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (271, xmlparse(document '
<customerinfo>
    <id>271</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (272, xmlparse(document '
<customerinfo>
    <id>272</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (273, xmlparse(document '
<customerinfo>
    <id>273</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (274, xmlparse(document '
<customerinfo>
    <id>274</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (275, xmlparse(document '
<customerinfo>
    <id>275</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (276, xmlparse(document '
<customerinfo>
    <id>276</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (277, xmlparse(document '
<customerinfo>
    <id>277</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (278, xmlparse(document '
<customerinfo>
    <id>278</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (279, xmlparse(document '
<customerinfo>
    <id>279</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (280, xmlparse(document '
<customerinfo>
    <id>280</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (281, xmlparse(document '
<customerinfo>
    <id>281</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (282, xmlparse(document '
<customerinfo>
    <id>282</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (283, xmlparse(document '
<customerinfo>
    <id>283</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (284, xmlparse(document '
<customerinfo>
    <id>284</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (285, xmlparse(document '
<customerinfo>
    <id>285</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (286, xmlparse(document '
<customerinfo>
    <id>286</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (287, xmlparse(document '
<customerinfo>
    <id>287</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (288, xmlparse(document '
<customerinfo>
    <id>288</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (289, xmlparse(document '
<customerinfo>
    <id>289</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (290, xmlparse(document '
<customerinfo>
    <id>290</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (291, xmlparse(document '
<customerinfo>
    <id>291</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (292, xmlparse(document '
<customerinfo>
    <id>292</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (293, xmlparse(document '
<customerinfo>
    <id>293</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (294, xmlparse(document '
<customerinfo>
    <id>294</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (295, xmlparse(document '
<customerinfo>
    <id>295</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (296, xmlparse(document '
<customerinfo>
    <id>296</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (297, xmlparse(document '
<customerinfo>
    <id>297</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (298, xmlparse(document '
<customerinfo>
    <id>298</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (299, xmlparse(document '
<customerinfo>
    <id>299</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (300, xmlparse(document '
<customerinfo>
    <id>300</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (301, xmlparse(document '
<customerinfo>
    <id>301</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (302, xmlparse(document '
<customerinfo>
    <id>302</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (303, xmlparse(document '
<customerinfo>
    <id>303</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (304, xmlparse(document '
<customerinfo>
    <id>304</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (305, xmlparse(document '
<customerinfo>
    <id>305</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (306, xmlparse(document '
<customerinfo>
    <id>306</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (307, xmlparse(document '
<customerinfo>
    <id>307</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (308, xmlparse(document '
<customerinfo>
    <id>308</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (309, xmlparse(document '
<customerinfo>
    <id>309</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (310, xmlparse(document '
<customerinfo>
    <id>310</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (311, xmlparse(document '
<customerinfo>
    <id>311</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (312, xmlparse(document '
<customerinfo>
    <id>312</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (313, xmlparse(document '
<customerinfo>
    <id>313</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (314, xmlparse(document '
<customerinfo>
    <id>314</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (315, xmlparse(document '
<customerinfo>
    <id>315</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (316, xmlparse(document '
<customerinfo>
    <id>316</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (317, xmlparse(document '
<customerinfo>
    <id>317</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (318, xmlparse(document '
<customerinfo>
    <id>318</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (319, xmlparse(document '
<customerinfo>
    <id>319</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (320, xmlparse(document '
<customerinfo>
    <id>320</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (321, xmlparse(document '
<customerinfo>
    <id>321</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (322, xmlparse(document '
<customerinfo>
    <id>322</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (323, xmlparse(document '
<customerinfo>
    <id>323</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (324, xmlparse(document '
<customerinfo>
    <id>324</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (325, xmlparse(document '
<customerinfo>
    <id>325</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (326, xmlparse(document '
<customerinfo>
    <id>326</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (327, xmlparse(document '
<customerinfo>
    <id>327</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (328, xmlparse(document '
<customerinfo>
    <id>328</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (329, xmlparse(document '
<customerinfo>
    <id>329</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (330, xmlparse(document '
<customerinfo>
    <id>330</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (331, xmlparse(document '
<customerinfo>
    <id>331</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (332, xmlparse(document '
<customerinfo>
    <id>332</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (333, xmlparse(document '
<customerinfo>
    <id>333</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (334, xmlparse(document '
<customerinfo>
    <id>334</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (335, xmlparse(document '
<customerinfo>
    <id>335</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (336, xmlparse(document '
<customerinfo>
    <id>336</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (337, xmlparse(document '
<customerinfo>
    <id>337</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (338, xmlparse(document '
<customerinfo>
    <id>338</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (339, xmlparse(document '
<customerinfo>
    <id>339</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (340, xmlparse(document '
<customerinfo>
    <id>340</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (341, xmlparse(document '
<customerinfo>
    <id>341</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (342, xmlparse(document '
<customerinfo>
    <id>342</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (343, xmlparse(document '
<customerinfo>
    <id>343</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (344, xmlparse(document '
<customerinfo>
    <id>344</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (345, xmlparse(document '
<customerinfo>
    <id>345</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (346, xmlparse(document '
<customerinfo>
    <id>346</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (347, xmlparse(document '
<customerinfo>
    <id>347</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (348, xmlparse(document '
<customerinfo>
    <id>348</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (349, xmlparse(document '
<customerinfo>
    <id>349</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (350, xmlparse(document '
<customerinfo>
    <id>350</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (351, xmlparse(document '
<customerinfo>
    <id>351</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (352, xmlparse(document '
<customerinfo>
    <id>352</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (353, xmlparse(document '
<customerinfo>
    <id>353</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (354, xmlparse(document '
<customerinfo>
    <id>354</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (355, xmlparse(document '
<customerinfo>
    <id>355</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (356, xmlparse(document '
<customerinfo>
    <id>356</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (357, xmlparse(document '
<customerinfo>
    <id>357</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (358, xmlparse(document '
<customerinfo>
    <id>358</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (359, xmlparse(document '
<customerinfo>
    <id>359</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (360, xmlparse(document '
<customerinfo>
    <id>360</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (361, xmlparse(document '
<customerinfo>
    <id>361</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (362, xmlparse(document '
<customerinfo>
    <id>362</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (363, xmlparse(document '
<customerinfo>
    <id>363</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (364, xmlparse(document '
<customerinfo>
    <id>364</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (365, xmlparse(document '
<customerinfo>
    <id>365</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (366, xmlparse(document '
<customerinfo>
    <id>366</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (367, xmlparse(document '
<customerinfo>
    <id>367</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (368, xmlparse(document '
<customerinfo>
    <id>368</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (369, xmlparse(document '
<customerinfo>
    <id>369</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (370, xmlparse(document '
<customerinfo>
    <id>370</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (371, xmlparse(document '
<customerinfo>
    <id>371</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (372, xmlparse(document '
<customerinfo>
    <id>372</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (373, xmlparse(document '
<customerinfo>
    <id>373</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (374, xmlparse(document '
<customerinfo>
    <id>374</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (375, xmlparse(document '
<customerinfo>
    <id>375</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (376, xmlparse(document '
<customerinfo>
    <id>376</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (377, xmlparse(document '
<customerinfo>
    <id>377</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (378, xmlparse(document '
<customerinfo>
    <id>378</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (379, xmlparse(document '
<customerinfo>
    <id>379</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (380, xmlparse(document '
<customerinfo>
    <id>380</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (381, xmlparse(document '
<customerinfo>
    <id>381</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (382, xmlparse(document '
<customerinfo>
    <id>382</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (383, xmlparse(document '
<customerinfo>
    <id>383</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (384, xmlparse(document '
<customerinfo>
    <id>384</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (385, xmlparse(document '
<customerinfo>
    <id>385</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (386, xmlparse(document '
<customerinfo>
    <id>386</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (387, xmlparse(document '
<customerinfo>
    <id>387</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (388, xmlparse(document '
<customerinfo>
    <id>388</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (389, xmlparse(document '
<customerinfo>
    <id>389</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (390, xmlparse(document '
<customerinfo>
    <id>390</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (391, xmlparse(document '
<customerinfo>
    <id>391</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (392, xmlparse(document '
<customerinfo>
    <id>392</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (393, xmlparse(document '
<customerinfo>
    <id>393</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (394, xmlparse(document '
<customerinfo>
    <id>394</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (395, xmlparse(document '
<customerinfo>
    <id>395</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (396, xmlparse(document '
<customerinfo>
    <id>396</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (397, xmlparse(document '
<customerinfo>
    <id>397</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (398, xmlparse(document '
<customerinfo>
    <id>398</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (399, xmlparse(document '
<customerinfo>
    <id>399</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (400, xmlparse(document '
<customerinfo>
    <id>400</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (401, xmlparse(document '
<customerinfo>
    <id>401</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (402, xmlparse(document '
<customerinfo>
    <id>402</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (403, xmlparse(document '
<customerinfo>
    <id>403</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (404, xmlparse(document '
<customerinfo>
    <id>404</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (405, xmlparse(document '
<customerinfo>
    <id>405</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (406, xmlparse(document '
<customerinfo>
    <id>406</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (407, xmlparse(document '
<customerinfo>
    <id>407</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (408, xmlparse(document '
<customerinfo>
    <id>408</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (409, xmlparse(document '
<customerinfo>
    <id>409</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (410, xmlparse(document '
<customerinfo>
    <id>410</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (411, xmlparse(document '
<customerinfo>
    <id>411</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (412, xmlparse(document '
<customerinfo>
    <id>412</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (413, xmlparse(document '
<customerinfo>
    <id>413</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (414, xmlparse(document '
<customerinfo>
    <id>414</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (415, xmlparse(document '
<customerinfo>
    <id>415</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (416, xmlparse(document '
<customerinfo>
    <id>416</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (417, xmlparse(document '
<customerinfo>
    <id>417</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (418, xmlparse(document '
<customerinfo>
    <id>418</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (419, xmlparse(document '
<customerinfo>
    <id>419</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (420, xmlparse(document '
<customerinfo>
    <id>420</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (421, xmlparse(document '
<customerinfo>
    <id>421</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (422, xmlparse(document '
<customerinfo>
    <id>422</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (423, xmlparse(document '
<customerinfo>
    <id>423</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (424, xmlparse(document '
<customerinfo>
    <id>424</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (425, xmlparse(document '
<customerinfo>
    <id>425</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (426, xmlparse(document '
<customerinfo>
    <id>426</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (427, xmlparse(document '
<customerinfo>
    <id>427</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (428, xmlparse(document '
<customerinfo>
    <id>428</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (429, xmlparse(document '
<customerinfo>
    <id>429</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (430, xmlparse(document '
<customerinfo>
    <id>430</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (431, xmlparse(document '
<customerinfo>
    <id>431</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (432, xmlparse(document '
<customerinfo>
    <id>432</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (433, xmlparse(document '
<customerinfo>
    <id>433</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (434, xmlparse(document '
<customerinfo>
    <id>434</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (435, xmlparse(document '
<customerinfo>
    <id>435</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (436, xmlparse(document '
<customerinfo>
    <id>436</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (437, xmlparse(document '
<customerinfo>
    <id>437</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (438, xmlparse(document '
<customerinfo>
    <id>438</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (439, xmlparse(document '
<customerinfo>
    <id>439</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (440, xmlparse(document '
<customerinfo>
    <id>440</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (441, xmlparse(document '
<customerinfo>
    <id>441</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (442, xmlparse(document '
<customerinfo>
    <id>442</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (443, xmlparse(document '
<customerinfo>
    <id>443</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (444, xmlparse(document '
<customerinfo>
    <id>444</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (445, xmlparse(document '
<customerinfo>
    <id>445</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (446, xmlparse(document '
<customerinfo>
    <id>446</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (447, xmlparse(document '
<customerinfo>
    <id>447</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (448, xmlparse(document '
<customerinfo>
    <id>448</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (449, xmlparse(document '
<customerinfo>
    <id>449</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (450, xmlparse(document '
<customerinfo>
    <id>450</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (451, xmlparse(document '
<customerinfo>
    <id>451</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (452, xmlparse(document '
<customerinfo>
    <id>452</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (453, xmlparse(document '
<customerinfo>
    <id>453</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (454, xmlparse(document '
<customerinfo>
    <id>454</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (455, xmlparse(document '
<customerinfo>
    <id>455</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (456, xmlparse(document '
<customerinfo>
    <id>456</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (457, xmlparse(document '
<customerinfo>
    <id>457</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (458, xmlparse(document '
<customerinfo>
    <id>458</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (459, xmlparse(document '
<customerinfo>
    <id>459</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (460, xmlparse(document '
<customerinfo>
    <id>460</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (461, xmlparse(document '
<customerinfo>
    <id>461</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (462, xmlparse(document '
<customerinfo>
    <id>462</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (463, xmlparse(document '
<customerinfo>
    <id>463</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (464, xmlparse(document '
<customerinfo>
    <id>464</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (465, xmlparse(document '
<customerinfo>
    <id>465</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (466, xmlparse(document '
<customerinfo>
    <id>466</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (467, xmlparse(document '
<customerinfo>
    <id>467</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (468, xmlparse(document '
<customerinfo>
    <id>468</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (469, xmlparse(document '
<customerinfo>
    <id>469</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (470, xmlparse(document '
<customerinfo>
    <id>470</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (471, xmlparse(document '
<customerinfo>
    <id>471</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (472, xmlparse(document '
<customerinfo>
    <id>472</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (473, xmlparse(document '
<customerinfo>
    <id>473</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (474, xmlparse(document '
<customerinfo>
    <id>474</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (475, xmlparse(document '
<customerinfo>
    <id>475</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (476, xmlparse(document '
<customerinfo>
    <id>476</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (477, xmlparse(document '
<customerinfo>
    <id>477</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (478, xmlparse(document '
<customerinfo>
    <id>478</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (479, xmlparse(document '
<customerinfo>
    <id>479</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (480, xmlparse(document '
<customerinfo>
    <id>480</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (481, xmlparse(document '
<customerinfo>
    <id>481</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (482, xmlparse(document '
<customerinfo>
    <id>482</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (483, xmlparse(document '
<customerinfo>
    <id>483</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (484, xmlparse(document '
<customerinfo>
    <id>484</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (485, xmlparse(document '
<customerinfo>
    <id>485</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (486, xmlparse(document '
<customerinfo>
    <id>486</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (487, xmlparse(document '
<customerinfo>
    <id>487</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (488, xmlparse(document '
<customerinfo>
    <id>488</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (489, xmlparse(document '
<customerinfo>
    <id>489</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (490, xmlparse(document '
<customerinfo>
    <id>490</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (491, xmlparse(document '
<customerinfo>
    <id>491</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (492, xmlparse(document '
<customerinfo>
    <id>492</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (493, xmlparse(document '
<customerinfo>
    <id>493</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (494, xmlparse(document '
<customerinfo>
    <id>494</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (495, xmlparse(document '
<customerinfo>
    <id>495</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (496, xmlparse(document '
<customerinfo>
    <id>496</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (497, xmlparse(document '
<customerinfo>
    <id>497</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (498, xmlparse(document '
<customerinfo>
    <id>498</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (499, xmlparse(document '
<customerinfo>
    <id>499</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

echo Half Way There;

insert into XMLCUSTOMER values (500, xmlparse(document '
<customerinfo>
    <id>500</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (501, xmlparse(document '
<customerinfo>
    <id>501</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (502, xmlparse(document '
<customerinfo>
    <id>502</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (503, xmlparse(document '
<customerinfo>
    <id>503</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (504, xmlparse(document '
<customerinfo>
    <id>504</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (505, xmlparse(document '
<customerinfo>
    <id>505</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (506, xmlparse(document '
<customerinfo>
    <id>506</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (507, xmlparse(document '
<customerinfo>
    <id>507</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (508, xmlparse(document '
<customerinfo>
    <id>508</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (509, xmlparse(document '
<customerinfo>
    <id>509</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (510, xmlparse(document '
<customerinfo>
    <id>510</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (511, xmlparse(document '
<customerinfo>
    <id>511</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (512, xmlparse(document '
<customerinfo>
    <id>512</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (513, xmlparse(document '
<customerinfo>
    <id>513</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (514, xmlparse(document '
<customerinfo>
    <id>514</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (515, xmlparse(document '
<customerinfo>
    <id>515</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (516, xmlparse(document '
<customerinfo>
    <id>516</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (517, xmlparse(document '
<customerinfo>
    <id>517</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (518, xmlparse(document '
<customerinfo>
    <id>518</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (519, xmlparse(document '
<customerinfo>
    <id>519</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (520, xmlparse(document '
<customerinfo>
    <id>520</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (521, xmlparse(document '
<customerinfo>
    <id>521</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (522, xmlparse(document '
<customerinfo>
    <id>522</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (523, xmlparse(document '
<customerinfo>
    <id>523</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (524, xmlparse(document '
<customerinfo>
    <id>524</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (525, xmlparse(document '
<customerinfo>
    <id>525</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (526, xmlparse(document '
<customerinfo>
    <id>526</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (527, xmlparse(document '
<customerinfo>
    <id>527</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (528, xmlparse(document '
<customerinfo>
    <id>528</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (529, xmlparse(document '
<customerinfo>
    <id>529</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (530, xmlparse(document '
<customerinfo>
    <id>530</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (531, xmlparse(document '
<customerinfo>
    <id>531</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (532, xmlparse(document '
<customerinfo>
    <id>532</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (533, xmlparse(document '
<customerinfo>
    <id>533</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (534, xmlparse(document '
<customerinfo>
    <id>534</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (535, xmlparse(document '
<customerinfo>
    <id>535</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (536, xmlparse(document '
<customerinfo>
    <id>536</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (537, xmlparse(document '
<customerinfo>
    <id>537</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (538, xmlparse(document '
<customerinfo>
    <id>538</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (539, xmlparse(document '
<customerinfo>
    <id>539</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (540, xmlparse(document '
<customerinfo>
    <id>540</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (541, xmlparse(document '
<customerinfo>
    <id>541</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (542, xmlparse(document '
<customerinfo>
    <id>542</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (543, xmlparse(document '
<customerinfo>
    <id>543</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (544, xmlparse(document '
<customerinfo>
    <id>544</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (545, xmlparse(document '
<customerinfo>
    <id>545</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (546, xmlparse(document '
<customerinfo>
    <id>546</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (547, xmlparse(document '
<customerinfo>
    <id>547</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (548, xmlparse(document '
<customerinfo>
    <id>548</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (549, xmlparse(document '
<customerinfo>
    <id>549</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (550, xmlparse(document '
<customerinfo>
    <id>550</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (551, xmlparse(document '
<customerinfo>
    <id>551</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (552, xmlparse(document '
<customerinfo>
    <id>552</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (553, xmlparse(document '
<customerinfo>
    <id>553</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (554, xmlparse(document '
<customerinfo>
    <id>554</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (555, xmlparse(document '
<customerinfo>
    <id>555</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (556, xmlparse(document '
<customerinfo>
    <id>556</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (557, xmlparse(document '
<customerinfo>
    <id>557</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (558, xmlparse(document '
<customerinfo>
    <id>558</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (559, xmlparse(document '
<customerinfo>
    <id>559</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (560, xmlparse(document '
<customerinfo>
    <id>560</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (561, xmlparse(document '
<customerinfo>
    <id>561</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (562, xmlparse(document '
<customerinfo>
    <id>562</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (563, xmlparse(document '
<customerinfo>
    <id>563</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (564, xmlparse(document '
<customerinfo>
    <id>564</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (565, xmlparse(document '
<customerinfo>
    <id>565</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (566, xmlparse(document '
<customerinfo>
    <id>566</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (567, xmlparse(document '
<customerinfo>
    <id>567</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (568, xmlparse(document '
<customerinfo>
    <id>568</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (569, xmlparse(document '
<customerinfo>
    <id>569</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (570, xmlparse(document '
<customerinfo>
    <id>570</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (571, xmlparse(document '
<customerinfo>
    <id>571</id>
    <name>John Smith</name>
    <addr country="Canada">
        <street>Gifford</street>
        <city>Burbank</city>
        <prov-state>Nova Scotia</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (572, xmlparse(document '
<customerinfo>
    <id>572</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (573, xmlparse(document '
<customerinfo>
    <id>573</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (574, xmlparse(document '
<customerinfo>
    <id>574</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (575, xmlparse(document '
<customerinfo>
    <id>575</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (576, xmlparse(document '
<customerinfo>
    <id>576</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (577, xmlparse(document '
<customerinfo>
    <id>577</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (578, xmlparse(document '
<customerinfo>
    <id>578</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (579, xmlparse(document '
<customerinfo>
    <id>579</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (580, xmlparse(document '
<customerinfo>
    <id>580</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (581, xmlparse(document '
<customerinfo>
    <id>581</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (582, xmlparse(document '
<customerinfo>
    <id>582</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (583, xmlparse(document '
<customerinfo>
    <id>583</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (584, xmlparse(document '
<customerinfo>
    <id>584</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (585, xmlparse(document '
<customerinfo>
    <id>585</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (586, xmlparse(document '
<customerinfo>
    <id>586</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (587, xmlparse(document '
<customerinfo>
    <id>587</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (588, xmlparse(document '
<customerinfo>
    <id>588</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (589, xmlparse(document '
<customerinfo>
    <id>589</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (590, xmlparse(document '
<customerinfo>
    <id>590</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (591, xmlparse(document '
<customerinfo>
    <id>591</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (592, xmlparse(document '
<customerinfo>
    <id>592</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (593, xmlparse(document '
<customerinfo>
    <id>593</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (594, xmlparse(document '
<customerinfo>
    <id>594</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (595, xmlparse(document '
<customerinfo>
    <id>595</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (596, xmlparse(document '
<customerinfo>
    <id>596</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (597, xmlparse(document '
<customerinfo>
    <id>597</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (598, xmlparse(document '
<customerinfo>
    <id>598</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (599, xmlparse(document '
<customerinfo>
    <id>599</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (600, xmlparse(document '
<customerinfo>
    <id>600</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (601, xmlparse(document '
<customerinfo>
    <id>601</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (602, xmlparse(document '
<customerinfo>
    <id>602</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (603, xmlparse(document '
<customerinfo>
    <id>603</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (604, xmlparse(document '
<customerinfo>
    <id>604</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (605, xmlparse(document '
<customerinfo>
    <id>605</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (606, xmlparse(document '
<customerinfo>
    <id>606</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (607, xmlparse(document '
<customerinfo>
    <id>607</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (608, xmlparse(document '
<customerinfo>
    <id>608</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (609, xmlparse(document '
<customerinfo>
    <id>609</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (610, xmlparse(document '
<customerinfo>
    <id>610</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (611, xmlparse(document '
<customerinfo>
    <id>611</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (612, xmlparse(document '
<customerinfo>
    <id>612</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (613, xmlparse(document '
<customerinfo>
    <id>613</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (614, xmlparse(document '
<customerinfo>
    <id>614</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (615, xmlparse(document '
<customerinfo>
    <id>615</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (616, xmlparse(document '
<customerinfo>
    <id>616</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (617, xmlparse(document '
<customerinfo>
    <id>617</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (618, xmlparse(document '
<customerinfo>
    <id>618</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (619, xmlparse(document '
<customerinfo>
    <id>619</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (620, xmlparse(document '
<customerinfo>
    <id>620</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (621, xmlparse(document '
<customerinfo>
    <id>621</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (622, xmlparse(document '
<customerinfo>
    <id>622</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (623, xmlparse(document '
<customerinfo>
    <id>623</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (624, xmlparse(document '
<customerinfo>
    <id>624</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (625, xmlparse(document '
<customerinfo>
    <id>625</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (626, xmlparse(document '
<customerinfo>
    <id>626</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (627, xmlparse(document '
<customerinfo>
    <id>627</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (628, xmlparse(document '
<customerinfo>
    <id>628</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (629, xmlparse(document '
<customerinfo>
    <id>629</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (630, xmlparse(document '
<customerinfo>
    <id>630</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (631, xmlparse(document '
<customerinfo>
    <id>631</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (632, xmlparse(document '
<customerinfo>
    <id>632</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (633, xmlparse(document '
<customerinfo>
    <id>633</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (634, xmlparse(document '
<customerinfo>
    <id>634</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (635, xmlparse(document '
<customerinfo>
    <id>635</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (636, xmlparse(document '
<customerinfo>
    <id>636</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (637, xmlparse(document '
<customerinfo>
    <id>637</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (638, xmlparse(document '
<customerinfo>
    <id>638</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (639, xmlparse(document '
<customerinfo>
    <id>639</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (640, xmlparse(document '
<customerinfo>
    <id>640</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (641, xmlparse(document '
<customerinfo>
    <id>641</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (642, xmlparse(document '
<customerinfo>
    <id>642</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (643, xmlparse(document '
<customerinfo>
    <id>643</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (644, xmlparse(document '
<customerinfo>
    <id>644</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (645, xmlparse(document '
<customerinfo>
    <id>645</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (646, xmlparse(document '
<customerinfo>
    <id>646</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (647, xmlparse(document '
<customerinfo>
    <id>647</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (648, xmlparse(document '
<customerinfo>
    <id>648</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (649, xmlparse(document '
<customerinfo>
    <id>649</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (650, xmlparse(document '
<customerinfo>
    <id>650</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (651, xmlparse(document '
<customerinfo>
    <id>651</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (652, xmlparse(document '
<customerinfo>
    <id>652</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (653, xmlparse(document '
<customerinfo>
    <id>653</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (654, xmlparse(document '
<customerinfo>
    <id>654</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (655, xmlparse(document '
<customerinfo>
    <id>655</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (656, xmlparse(document '
<customerinfo>
    <id>656</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (657, xmlparse(document '
<customerinfo>
    <id>657</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (658, xmlparse(document '
<customerinfo>
    <id>658</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (659, xmlparse(document '
<customerinfo>
    <id>659</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (660, xmlparse(document '
<customerinfo>
    <id>660</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (661, xmlparse(document '
<customerinfo>
    <id>661</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (662, xmlparse(document '
<customerinfo>
    <id>662</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (663, xmlparse(document '
<customerinfo>
    <id>663</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (664, xmlparse(document '
<customerinfo>
    <id>664</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (665, xmlparse(document '
<customerinfo>
    <id>665</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (666, xmlparse(document '
<customerinfo>
    <id>666</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (667, xmlparse(document '
<customerinfo>
    <id>667</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (668, xmlparse(document '
<customerinfo>
    <id>668</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (669, xmlparse(document '
<customerinfo>
    <id>669</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (670, xmlparse(document '
<customerinfo>
    <id>670</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (671, xmlparse(document '
<customerinfo>
    <id>671</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (672, xmlparse(document '
<customerinfo>
    <id>672</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (673, xmlparse(document '
<customerinfo>
    <id>673</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (674, xmlparse(document '
<customerinfo>
    <id>674</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (675, xmlparse(document '
<customerinfo>
    <id>675</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (676, xmlparse(document '
<customerinfo>
    <id>676</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (677, xmlparse(document '
<customerinfo>
    <id>677</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (678, xmlparse(document '
<customerinfo>
    <id>678</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (679, xmlparse(document '
<customerinfo>
    <id>679</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (680, xmlparse(document '
<customerinfo>
    <id>680</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (681, xmlparse(document '
<customerinfo>
    <id>681</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (682, xmlparse(document '
<customerinfo>
    <id>682</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (683, xmlparse(document '
<customerinfo>
    <id>683</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (684, xmlparse(document '
<customerinfo>
    <id>684</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (685, xmlparse(document '
<customerinfo>
    <id>685</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (686, xmlparse(document '
<customerinfo>
    <id>686</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (687, xmlparse(document '
<customerinfo>
    <id>687</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (688, xmlparse(document '
<customerinfo>
    <id>688</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (689, xmlparse(document '
<customerinfo>
    <id>689</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (690, xmlparse(document '
<customerinfo>
    <id>690</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (691, xmlparse(document '
<customerinfo>
    <id>691</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (692, xmlparse(document '
<customerinfo>
    <id>692</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (693, xmlparse(document '
<customerinfo>
    <id>693</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (694, xmlparse(document '
<customerinfo>
    <id>694</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (695, xmlparse(document '
<customerinfo>
    <id>695</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (696, xmlparse(document '
<customerinfo>
    <id>696</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (697, xmlparse(document '
<customerinfo>
    <id>697</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (698, xmlparse(document '
<customerinfo>
    <id>698</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (699, xmlparse(document '
<customerinfo>
    <id>699</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (700, xmlparse(document '
<customerinfo>
    <id>700</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (701, xmlparse(document '
<customerinfo>
    <id>701</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (702, xmlparse(document '
<customerinfo>
    <id>702</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (703, xmlparse(document '
<customerinfo>
    <id>703</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (704, xmlparse(document '
<customerinfo>
    <id>704</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (705, xmlparse(document '
<customerinfo>
    <id>705</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (706, xmlparse(document '
<customerinfo>
    <id>706</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (707, xmlparse(document '
<customerinfo>
    <id>707</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (708, xmlparse(document '
<customerinfo>
    <id>708</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (709, xmlparse(document '
<customerinfo>
    <id>709</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (710, xmlparse(document '
<customerinfo>
    <id>710</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (711, xmlparse(document '
<customerinfo>
    <id>711</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (712, xmlparse(document '
<customerinfo>
    <id>712</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (713, xmlparse(document '
<customerinfo>
    <id>713</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (714, xmlparse(document '
<customerinfo>
    <id>714</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (715, xmlparse(document '
<customerinfo>
    <id>715</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (716, xmlparse(document '
<customerinfo>
    <id>716</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (717, xmlparse(document '
<customerinfo>
    <id>717</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (718, xmlparse(document '
<customerinfo>
    <id>718</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (719, xmlparse(document '
<customerinfo>
    <id>719</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (720, xmlparse(document '
<customerinfo>
    <id>720</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (721, xmlparse(document '
<customerinfo>
    <id>721</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (722, xmlparse(document '
<customerinfo>
    <id>722</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (723, xmlparse(document '
<customerinfo>
    <id>723</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (724, xmlparse(document '
<customerinfo>
    <id>724</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (725, xmlparse(document '
<customerinfo>
    <id>725</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (726, xmlparse(document '
<customerinfo>
    <id>726</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (727, xmlparse(document '
<customerinfo>
    <id>727</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (728, xmlparse(document '
<customerinfo>
    <id>728</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (729, xmlparse(document '
<customerinfo>
    <id>729</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (730, xmlparse(document '
<customerinfo>
    <id>730</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (731, xmlparse(document '
<customerinfo>
    <id>731</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (732, xmlparse(document '
<customerinfo>
    <id>732</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (733, xmlparse(document '
<customerinfo>
    <id>733</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (734, xmlparse(document '
<customerinfo>
    <id>734</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (735, xmlparse(document '
<customerinfo>
    <id>735</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (736, xmlparse(document '
<customerinfo>
    <id>736</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (737, xmlparse(document '
<customerinfo>
    <id>737</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (738, xmlparse(document '
<customerinfo>
    <id>738</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (739, xmlparse(document '
<customerinfo>
    <id>739</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (740, xmlparse(document '
<customerinfo>
    <id>740</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (741, xmlparse(document '
<customerinfo>
    <id>741</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (742, xmlparse(document '
<customerinfo>
    <id>742</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (743, xmlparse(document '
<customerinfo>
    <id>743</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (744, xmlparse(document '
<customerinfo>
    <id>744</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (745, xmlparse(document '
<customerinfo>
    <id>745</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (746, xmlparse(document '
<customerinfo>
    <id>746</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (747, xmlparse(document '
<customerinfo>
    <id>747</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (748, xmlparse(document '
<customerinfo>
    <id>748</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (749, xmlparse(document '
<customerinfo>
    <id>749</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (750, xmlparse(document '
<customerinfo>
    <id>750</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (751, xmlparse(document '
<customerinfo>
    <id>751</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (752, xmlparse(document '
<customerinfo>
    <id>752</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (753, xmlparse(document '
<customerinfo>
    <id>753</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (754, xmlparse(document '
<customerinfo>
    <id>754</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (755, xmlparse(document '
<customerinfo>
    <id>755</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (756, xmlparse(document '
<customerinfo>
    <id>756</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (757, xmlparse(document '
<customerinfo>
    <id>757</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (758, xmlparse(document '
<customerinfo>
    <id>758</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (759, xmlparse(document '
<customerinfo>
    <id>759</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (760, xmlparse(document '
<customerinfo>
    <id>760</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (761, xmlparse(document '
<customerinfo>
    <id>761</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (762, xmlparse(document '
<customerinfo>
    <id>762</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (763, xmlparse(document '
<customerinfo>
    <id>763</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (764, xmlparse(document '
<customerinfo>
    <id>764</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (765, xmlparse(document '
<customerinfo>
    <id>765</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (766, xmlparse(document '
<customerinfo>
    <id>766</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (767, xmlparse(document '
<customerinfo>
    <id>767</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (768, xmlparse(document '
<customerinfo>
    <id>768</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (769, xmlparse(document '
<customerinfo>
    <id>769</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (770, xmlparse(document '
<customerinfo>
    <id>770</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (771, xmlparse(document '
<customerinfo>
    <id>771</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (772, xmlparse(document '
<customerinfo>
    <id>772</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (773, xmlparse(document '
<customerinfo>
    <id>773</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (774, xmlparse(document '
<customerinfo>
    <id>774</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (775, xmlparse(document '
<customerinfo>
    <id>775</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (776, xmlparse(document '
<customerinfo>
    <id>776</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (777, xmlparse(document '
<customerinfo>
    <id>777</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (778, xmlparse(document '
<customerinfo>
    <id>778</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (779, xmlparse(document '
<customerinfo>
    <id>779</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (780, xmlparse(document '
<customerinfo>
    <id>780</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (781, xmlparse(document '
<customerinfo>
    <id>781</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (782, xmlparse(document '
<customerinfo>
    <id>782</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (783, xmlparse(document '
<customerinfo>
    <id>783</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (784, xmlparse(document '
<customerinfo>
    <id>784</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (785, xmlparse(document '
<customerinfo>
    <id>785</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (786, xmlparse(document '
<customerinfo>
    <id>786</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (787, xmlparse(document '
<customerinfo>
    <id>787</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (788, xmlparse(document '
<customerinfo>
    <id>788</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (789, xmlparse(document '
<customerinfo>
    <id>789</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (790, xmlparse(document '
<customerinfo>
    <id>790</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (791, xmlparse(document '
<customerinfo>
    <id>791</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (792, xmlparse(document '
<customerinfo>
    <id>792</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (793, xmlparse(document '
<customerinfo>
    <id>793</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (794, xmlparse(document '
<customerinfo>
    <id>794</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (795, xmlparse(document '
<customerinfo>
    <id>795</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (796, xmlparse(document '
<customerinfo>
    <id>796</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (797, xmlparse(document '
<customerinfo>
    <id>797</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (798, xmlparse(document '
<customerinfo>
    <id>798</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (799, xmlparse(document '
<customerinfo>
    <id>799</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (800, xmlparse(document '
<customerinfo>
    <id>800</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (801, xmlparse(document '
<customerinfo>
    <id>801</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (802, xmlparse(document '
<customerinfo>
    <id>802</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (803, xmlparse(document '
<customerinfo>
    <id>803</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (804, xmlparse(document '
<customerinfo>
    <id>804</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (805, xmlparse(document '
<customerinfo>
    <id>805</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (806, xmlparse(document '
<customerinfo>
    <id>806</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (807, xmlparse(document '
<customerinfo>
    <id>807</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (808, xmlparse(document '
<customerinfo>
    <id>808</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (809, xmlparse(document '
<customerinfo>
    <id>809</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (810, xmlparse(document '
<customerinfo>
    <id>810</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (811, xmlparse(document '
<customerinfo>
    <id>811</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (812, xmlparse(document '
<customerinfo>
    <id>812</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (813, xmlparse(document '
<customerinfo>
    <id>813</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (814, xmlparse(document '
<customerinfo>
    <id>814</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (815, xmlparse(document '
<customerinfo>
    <id>815</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (816, xmlparse(document '
<customerinfo>
    <id>816</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (817, xmlparse(document '
<customerinfo>
    <id>817</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (818, xmlparse(document '
<customerinfo>
    <id>818</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (819, xmlparse(document '
<customerinfo>
    <id>819</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (820, xmlparse(document '
<customerinfo>
    <id>820</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (821, xmlparse(document '
<customerinfo>
    <id>821</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (822, xmlparse(document '
<customerinfo>
    <id>822</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (823, xmlparse(document '
<customerinfo>
    <id>823</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (824, xmlparse(document '
<customerinfo>
    <id>824</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (825, xmlparse(document '
<customerinfo>
    <id>825</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (826, xmlparse(document '
<customerinfo>
    <id>826</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (827, xmlparse(document '
<customerinfo>
    <id>827</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (828, xmlparse(document '
<customerinfo>
    <id>828</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (829, xmlparse(document '
<customerinfo>
    <id>829</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (830, xmlparse(document '
<customerinfo>
    <id>830</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (831, xmlparse(document '
<customerinfo>
    <id>831</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (832, xmlparse(document '
<customerinfo>
    <id>832</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (833, xmlparse(document '
<customerinfo>
    <id>833</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (834, xmlparse(document '
<customerinfo>
    <id>834</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (835, xmlparse(document '
<customerinfo>
    <id>835</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (836, xmlparse(document '
<customerinfo>
    <id>836</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (837, xmlparse(document '
<customerinfo>
    <id>837</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (838, xmlparse(document '
<customerinfo>
    <id>838</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (839, xmlparse(document '
<customerinfo>
    <id>839</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (840, xmlparse(document '
<customerinfo>
    <id>840</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (841, xmlparse(document '
<customerinfo>
    <id>841</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (842, xmlparse(document '
<customerinfo>
    <id>842</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (843, xmlparse(document '
<customerinfo>
    <id>843</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (844, xmlparse(document '
<customerinfo>
    <id>844</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (845, xmlparse(document '
<customerinfo>
    <id>845</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (846, xmlparse(document '
<customerinfo>
    <id>846</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (847, xmlparse(document '
<customerinfo>
    <id>847</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (848, xmlparse(document '
<customerinfo>
    <id>848</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (849, xmlparse(document '
<customerinfo>
    <id>849</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (850, xmlparse(document '
<customerinfo>
    <id>850</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (851, xmlparse(document '
<customerinfo>
    <id>851</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (852, xmlparse(document '
<customerinfo>
    <id>852</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (853, xmlparse(document '
<customerinfo>
    <id>853</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (854, xmlparse(document '
<customerinfo>
    <id>854</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (855, xmlparse(document '
<customerinfo>
    <id>855</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (856, xmlparse(document '
<customerinfo>
    <id>856</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (857, xmlparse(document '
<customerinfo>
    <id>857</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (858, xmlparse(document '
<customerinfo>
    <id>858</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (859, xmlparse(document '
<customerinfo>
    <id>859</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (860, xmlparse(document '
<customerinfo>
    <id>860</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (861, xmlparse(document '
<customerinfo>
    <id>861</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (862, xmlparse(document '
<customerinfo>
    <id>862</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (863, xmlparse(document '
<customerinfo>
    <id>863</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (864, xmlparse(document '
<customerinfo>
    <id>864</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (865, xmlparse(document '
<customerinfo>
    <id>865</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (866, xmlparse(document '
<customerinfo>
    <id>866</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (867, xmlparse(document '
<customerinfo>
    <id>867</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (868, xmlparse(document '
<customerinfo>
    <id>868</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (869, xmlparse(document '
<customerinfo>
    <id>869</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (870, xmlparse(document '
<customerinfo>
    <id>870</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (871, xmlparse(document '
<customerinfo>
    <id>871</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (872, xmlparse(document '
<customerinfo>
    <id>872</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (873, xmlparse(document '
<customerinfo>
    <id>873</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (874, xmlparse(document '
<customerinfo>
    <id>874</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (875, xmlparse(document '
<customerinfo>
    <id>875</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (876, xmlparse(document '
<customerinfo>
    <id>876</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (877, xmlparse(document '
<customerinfo>
    <id>877</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (878, xmlparse(document '
<customerinfo>
    <id>878</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (879, xmlparse(document '
<customerinfo>
    <id>879</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (880, xmlparse(document '
<customerinfo>
    <id>880</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (881, xmlparse(document '
<customerinfo>
    <id>881</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (882, xmlparse(document '
<customerinfo>
    <id>882</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (883, xmlparse(document '
<customerinfo>
    <id>883</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (884, xmlparse(document '
<customerinfo>
    <id>884</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (885, xmlparse(document '
<customerinfo>
    <id>885</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (886, xmlparse(document '
<customerinfo>
    <id>886</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (887, xmlparse(document '
<customerinfo>
    <id>887</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (888, xmlparse(document '
<customerinfo>
    <id>888</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (889, xmlparse(document '
<customerinfo>
    <id>889</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (890, xmlparse(document '
<customerinfo>
    <id>890</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (891, xmlparse(document '
<customerinfo>
    <id>891</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (892, xmlparse(document '
<customerinfo>
    <id>892</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (893, xmlparse(document '
<customerinfo>
    <id>893</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (894, xmlparse(document '
<customerinfo>
    <id>894</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (895, xmlparse(document '
<customerinfo>
    <id>895</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (896, xmlparse(document '
<customerinfo>
    <id>896</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (897, xmlparse(document '
<customerinfo>
    <id>897</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (898, xmlparse(document '
<customerinfo>
    <id>898</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (899, xmlparse(document '
<customerinfo>
    <id>899</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (900, xmlparse(document '
<customerinfo>
    <id>900</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (901, xmlparse(document '
<customerinfo>
    <id>901</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (902, xmlparse(document '
<customerinfo>
    <id>902</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (903, xmlparse(document '
<customerinfo>
    <id>903</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (904, xmlparse(document '
<customerinfo>
    <id>904</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (905, xmlparse(document '
<customerinfo>
    <id>905</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (906, xmlparse(document '
<customerinfo>
    <id>906</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (907, xmlparse(document '
<customerinfo>
    <id>907</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (908, xmlparse(document '
<customerinfo>
    <id>908</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (909, xmlparse(document '
<customerinfo>
    <id>909</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (910, xmlparse(document '
<customerinfo>
    <id>910</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (911, xmlparse(document '
<customerinfo>
    <id>911</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (912, xmlparse(document '
<customerinfo>
    <id>912</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (913, xmlparse(document '
<customerinfo>
    <id>913</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (914, xmlparse(document '
<customerinfo>
    <id>914</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (915, xmlparse(document '
<customerinfo>
    <id>915</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (916, xmlparse(document '
<customerinfo>
    <id>916</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (917, xmlparse(document '
<customerinfo>
    <id>917</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (918, xmlparse(document '
<customerinfo>
    <id>918</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (919, xmlparse(document '
<customerinfo>
    <id>919</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (920, xmlparse(document '
<customerinfo>
    <id>920</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (921, xmlparse(document '
<customerinfo>
    <id>921</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (922, xmlparse(document '
<customerinfo>
    <id>922</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (923, xmlparse(document '
<customerinfo>
    <id>923</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (924, xmlparse(document '
<customerinfo>
    <id>924</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (925, xmlparse(document '
<customerinfo>
    <id>925</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (926, xmlparse(document '
<customerinfo>
    <id>926</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (927, xmlparse(document '
<customerinfo>
    <id>927</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (928, xmlparse(document '
<customerinfo>
    <id>928</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (929, xmlparse(document '
<customerinfo>
    <id>929</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (930, xmlparse(document '
<customerinfo>
    <id>930</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (931, xmlparse(document '
<customerinfo>
    <id>931</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (932, xmlparse(document '
<customerinfo>
    <id>932</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (933, xmlparse(document '
<customerinfo>
    <id>933</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (934, xmlparse(document '
<customerinfo>
    <id>934</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (935, xmlparse(document '
<customerinfo>
    <id>935</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (936, xmlparse(document '
<customerinfo>
    <id>936</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (937, xmlparse(document '
<customerinfo>
    <id>937</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (938, xmlparse(document '
<customerinfo>
    <id>938</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (939, xmlparse(document '
<customerinfo>
    <id>939</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (940, xmlparse(document '
<customerinfo>
    <id>940</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (941, xmlparse(document '
<customerinfo>
    <id>941</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (942, xmlparse(document '
<customerinfo>
    <id>942</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (943, xmlparse(document '
<customerinfo>
    <id>943</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (944, xmlparse(document '
<customerinfo>
    <id>944</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (945, xmlparse(document '
<customerinfo>
    <id>945</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (946, xmlparse(document '
<customerinfo>
    <id>946</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (947, xmlparse(document '
<customerinfo>
    <id>947</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (948, xmlparse(document '
<customerinfo>
    <id>948</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (949, xmlparse(document '
<customerinfo>
    <id>949</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (950, xmlparse(document '
<customerinfo>
    <id>950</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (951, xmlparse(document '
<customerinfo>
    <id>951</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (952, xmlparse(document '
<customerinfo>
    <id>952</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (953, xmlparse(document '
<customerinfo>
    <id>953</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (954, xmlparse(document '
<customerinfo>
    <id>954</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (955, xmlparse(document '
<customerinfo>
    <id>955</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (956, xmlparse(document '
<customerinfo>
    <id>956</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (957, xmlparse(document '
<customerinfo>
    <id>957</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (958, xmlparse(document '
<customerinfo>
    <id>958</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (959, xmlparse(document '
<customerinfo>
    <id>959</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (960, xmlparse(document '
<customerinfo>
    <id>960</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (961, xmlparse(document '
<customerinfo>
    <id>961</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (962, xmlparse(document '
<customerinfo>
    <id>962</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (963, xmlparse(document '
<customerinfo>
    <id>963</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (964, xmlparse(document '
<customerinfo>
    <id>964</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (965, xmlparse(document '
<customerinfo>
    <id>965</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (966, xmlparse(document '
<customerinfo>
    <id>966</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (967, xmlparse(document '
<customerinfo>
    <id>967</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (968, xmlparse(document '
<customerinfo>
    <id>968</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (969, xmlparse(document '
<customerinfo>
    <id>969</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (970, xmlparse(document '
<customerinfo>
    <id>970</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (971, xmlparse(document '
<customerinfo>
    <id>971</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (972, xmlparse(document '
<customerinfo>
    <id>972</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (973, xmlparse(document '
<customerinfo>
    <id>973</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (974, xmlparse(document '
<customerinfo>
    <id>974</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (975, xmlparse(document '
<customerinfo>
    <id>975</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (976, xmlparse(document '
<customerinfo>
    <id>976</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (977, xmlparse(document '
<customerinfo>
    <id>977</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (978, xmlparse(document '
<customerinfo>
    <id>978</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (979, xmlparse(document '
<customerinfo>
    <id>979</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (980, xmlparse(document '
<customerinfo>
    <id>980</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (981, xmlparse(document '
<customerinfo>
    <id>981</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (982, xmlparse(document '
<customerinfo>
    <id>982</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (983, xmlparse(document '
<customerinfo>
    <id>983</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (984, xmlparse(document '
<customerinfo>
    <id>984</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (985, xmlparse(document '
<customerinfo>
    <id>985</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (986, xmlparse(document '
<customerinfo>
    <id>986</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (987, xmlparse(document '
<customerinfo>
    <id>987</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (988, xmlparse(document '
<customerinfo>
    <id>988</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (989, xmlparse(document '
<customerinfo>
    <id>989</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (990, xmlparse(document '
<customerinfo>
    <id>990</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (991, xmlparse(document '
<customerinfo>
    <id>991</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (992, xmlparse(document '
<customerinfo>
    <id>992</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (993, xmlparse(document '
<customerinfo>
    <id>993</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (994, xmlparse(document '
<customerinfo>
    <id>994</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (995, xmlparse(document '
<customerinfo>
    <id>995</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (996, xmlparse(document '
<customerinfo>
    <id>996</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (997, xmlparse(document '
<customerinfo>
    <id>997</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (998, xmlparse(document '
<customerinfo>
    <id>998</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>California</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

insert into XMLCUSTOMER values (999, xmlparse(document '
<customerinfo>
    <id>999</id>
    <name>John Smith</name>
    <addr country="United States">
        <street>808 Mayo St</street>
        <city>Burbank</city>
        <prov-state>New York</prov-state>
        <pcode-zip>91501</pcode-zip>
    </addr>
    <phone type="work">818-541-6380</phone>
</customerinfo>
'));

select count(*) as "Num_Xml_Docs" from XMLCUSTOMER;

CONNECT RESET ;

echo All Done;
