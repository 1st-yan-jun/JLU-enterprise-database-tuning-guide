echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CREATING DATABASE    ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE DEMO using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to DEMO;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING XML TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE XQJOINADDR (
		ADDRESS XML NOT NULL
	);

CREATE TABLE XQJOINPERS (
		PERSON XML NOT NULL
	);

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING TABLES FOR SHREDDING ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE ADDRESSSHRED (
	firstName VARCHAR(32) NOT NULL,
	lastName VARCHAR(32) NOT NULL,
	street VARCHAR(32) NOT NULL,
	city VARCHAR(32) NOT NULL,
	zipCode VARCHAR(32) NOT NULL
	);

CREATE TABLE PERSONSHRED (
	firstName VARCHAR(32) NOT NULL,
	lastName VARCHAR(32) NOT NULL,
	nickName VARCHAR(32) NOT NULL,
	ssNum VARCHAR (32) NOT NULL
	);


echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING SQL TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;


 CREATE TABLE sqlcustomer (
  Cid        BIGINT NOT NULL PRIMARY KEY,
  Name       VARCHAR(128),
  Country    VARCHAR(128),
  Street     VARCHAR(128),
  City       VARCHAR(128),
  Province   VARCHAR(128),
  Zip        VARCHAR(128),
  Phone      VARCHAR(128),
  Info       CLOB(32K)
 );
--
 
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING SQL TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "sqlcustomer.data" OF IXF MESSAGES "sqlcustomer.err" REPLACE INTO sqlcustomer;

CONNECT RESET ;
