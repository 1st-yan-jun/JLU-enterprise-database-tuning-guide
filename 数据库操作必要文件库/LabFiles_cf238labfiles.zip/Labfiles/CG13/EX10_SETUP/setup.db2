echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CREATING DATABASE    ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13XADB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13XADB;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~     CREATING TABLES     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

create table ORDERS.PO (POID int, PODATE date, POSTATUS char(10), PODOC XML);

create table ORDERS.ITEMS (ITEMID varchar(10), POID int, PRICE double, QTY smallint);

create table ORDERS.SHIPPING_ADDRESS (SHIPID varchar(10), ADDRESS1 varchar(40), ADDRESS2 varchar(40), CITY varchar(30), STATE varchar (10), ZIP varchar(10));

create table ORDERS.CUST_ADDRESS (CUSTID varchar(10), ADDRESS1 varchar(40), ADDRESS2 varchar(40), CITY varchar(30), STATE varchar (10), ZIP varchar(10));

CONNECT RESET ;





