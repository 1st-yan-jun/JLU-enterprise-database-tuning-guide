drop table ORDERS.PO;

create table ORDERS.PO (POID int, PODATE date, POSTATUS char(10), PODOC XML);

drop table ORDERS.ITEMS;

create table ORDERS.ITEMS (ITEMID varchar(10), POID int, PRICE double, QTY smallint);

drop table ORDERS.SHIPPING_ADDRESS;

create table ORDERS.SHIPPING_ADDRESS (SHIPID varchar(10), ADDRESS1 varchar(40), ADDRESS2 varchar(40), CITY varchar(30), STATE varchar (10), ZIP varchar(10));

drop table ORDERS.CUST_ADDRESS;

create table ORDERS.CUST_ADDRESS (CUSTID varchar(10), ADDRESS1 varchar(40), ADDRESS2 varchar(40), CITY varchar(30), STATE varchar (10), ZIP varchar(10));
