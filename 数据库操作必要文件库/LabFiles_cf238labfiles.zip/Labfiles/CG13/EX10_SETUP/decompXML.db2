
--deleting any existing rows just for lab purposes
delete from orders.po;
delete from orders.items;
delete from orders.cust_address;
delete from orders.shipping_address;

--decompose the XML documents
--First XML document is validated just to illustrate the variation in command.

decompose xml document po1.xml xmlschema orders.poxsd validate;

decompose xml document po2.xml xmlschema orders.poxsd;

decompose xml document po3.xml xmlschema orders.poxsd;

--observe the new rows inserted
select * from orders.po;
select * from orders.items;
select * from orders.cust_address;
select * from orders.shipping_address;

