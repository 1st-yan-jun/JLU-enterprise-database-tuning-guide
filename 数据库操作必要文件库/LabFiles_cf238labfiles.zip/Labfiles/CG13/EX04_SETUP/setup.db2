--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
--echo ~ Creating CG13X4DB Database  ~;
--echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE DATABASE CG13X4DB using codeset utf-8 territory us;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~    CONNECTING TO DB     ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

connect to CG13X4DB;

--

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING XML TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

CREATE TABLE xmlproduct (
  Pid         VARCHAR(10) NOT NULL PRIMARY KEY,
  Description XML
);
--
CREATE TABLE xmlcustomer (
  Cid        BIGINT NOT NULL PRIMARY KEY,
  Info       XML
);
-- 
CREATE TABLE xmlporder (
  POid   BIGINT NOT NULL PRIMARY KEY,
  POdate DATE,
  POrder XML
);

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~   CREATING SQL TABLES   ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

--
 CREATE TABLE sqlcustomer (
  Cid        BIGINT NOT NULL PRIMARY KEY,
  Name       VARCHAR(128),
  Country    VARCHAR(128),
  Street     VARCHAR(128),
  City       VARCHAR(128),
  Province   VARCHAR(128),
  Zip        VARCHAR(128),
  Phone      VARCHAR(128),
  Info       CLOB(32K)
 );
--
 
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING XML TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "xmlporder.data" OF IXF MESSAGES "xmlporder.err" REPLACE INTO xmlporder;
IMPORT FROM "xmlcustomer.data" OF IXF MESSAGES "xmlcustomer.err" REPLACE INTO xmlcustomer;
IMPORT FROM "xmlproduct.data" OF IXF MESSAGES "xmlproduct.err" REPLACE INTO xmlproduct;

echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;
echo ~  POPULATING SQL TABLES  ~;
echo ~~~~~~~~~~~~~~~~~~~~~~~~~~~;

IMPORT FROM "sqlcustomer.data" OF IXF MESSAGES "sqlcustomer.err" REPLACE INTO sqlcustomer;

CONNECT RESET ;



