select tabname, tbspace, index_tbspace 
from syscat.tables 
where tabschema = user 
order by tabname;
