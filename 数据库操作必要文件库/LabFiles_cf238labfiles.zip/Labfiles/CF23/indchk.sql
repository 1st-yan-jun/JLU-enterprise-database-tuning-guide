select substr(tabname,1,18), uniquerule, substr(indname,1,18),
substr(colnames,1,30)
from syscat.indexes
where indschema = user and uniquerule <> 'P'
order by tabname, indname;
