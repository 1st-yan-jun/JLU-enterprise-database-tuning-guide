 select substr(text,1,100) from syscat.checks
where constname = 'CCTYPE';
