static char sqla_program_id[40] = 
{111,65,65,66,65,73,65,69,73,78,83,84,48,49,32,32,76,79,66,70,
73,76,69,49,111,65,86,87,78,84,71,78,48,49,49,49,49,50,32,32};


#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {' ',' ',' ',' '}};


#line 1 "lobfile1.sqc"
/******************************************************************************
**
** Source File Name = lobfile.sqc  %I%
**
** Licensed Materials - Property of IBM
**
** (C) COPYRIGHT International Business Machines Corp. 1995
** All Rights Reserved.
**
** US Government Users Restricted Rights - Use, duplication or
** disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**
** PURPOSE: This sample program demonstrates the use LOB values.
**          The program creates a CURSOR and fetches the contents of
**          the ARTISTS.BIO CLOB from the MUSICDB database and then        
**          outputs the resume.
**
** an external function "check_error" is found in the file "util.c"
** which must be compiled along with this file.  Use the build script
** "bldxlcemb" or use the "makefile" included (type in "make lobfile"). 
**
**
**
**               NOTICE TO USERS OF THE SOURCE CODE EXAMPLES
**
**  INTERNATIONAL BUSINESS MACHINES CORPORATION PROVIDES THE SOURCE CODE
**  EXAMPLES, BOTH INDIVIDUALLY AND AS ONE OR MORE GROUPS, "AS IS" WITHOUT
**  WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT
**  LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
**  PARTICULAR PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE
**  OF THE SOURCE CODE EXAMPLES, BOTH INDIVIDUALLY AND AS ONE OR MORE GROUPS,
**  IS WITH YOU.  SHOULD ANY PART OF THE SOURCE CODE EXAMPLES PROVE
**  DEFECTIVE, YOU (AND NOT IBM) ASSUME THE ENTIRE COST IF ALL NECESSARY
**  SERVICING, REPAIR OR CORRECTION.
**
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sql.h>


/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 43 "lobfile1.sqc"


#define  CHECKERR(CE_STR)   if (check_error (CE_STR, &sqlca) != 0) return 1;

int main(int argc, char *argv[]) {

   
/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 49 "lobfile1.sqc"
 /* :rk.1:erk. */
      /*SQL TYPE IS CLOB_FILE*/
struct {
     unsigned long    name_length;
     unsigned long    data_length;
     unsigned long    file_options;
              char    name[255];
} 
#line 50 "lobfile1.sqc"
 resume;
      short lobind;
      char database[9];
      char userid[9];
      char password[19];
      long artno; 
   
/*
EXEC SQL END DECLARE SECTION;
*/

#line 56 "lobfile1.sqc"

   short num_args;

  printf( "Sample C program: LOBFILE\n" );

   do {
      fflush(stdin);
      printf("\nPlease enter the database to which you wish to connect:  \n");
      fgets(database,sizeof(database),stdin);
   }
   while (database[0] == '\n');

   if (database[strlen(database)-1] == '\n')
     database[strlen(database)-1] ='\0';
     /* replace newline with null terminator */

   do {
      fflush(stdin);
      printf("\nPlease enter your userid: \n");
      fgets(userid,sizeof(userid),stdin);
   }
   while (userid[0] == '\n');

   if (userid[strlen(userid)-1] == '\n')
     userid[strlen(userid)-1] ='\0';

   do {
      fflush(stdin);
      printf("\nPlease enter your password.");
      printf("\n(please be sure no one is looking over your shoulder) : \n");
      fgets(password,sizeof(password),stdin);
   }
   while (password[0] == '\n');

   if (password[strlen(password)-1] == '\n')
     password[strlen(password)-1] ='\0';
     /* replace newline with null terminator */

   
/*
EXEC SQL CONNECT TO :database USER :userid USING :password;
*/

{
#line 94 "lobfile1.sqc"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 94 "lobfile1.sqc"
  sqlaaloc(2,3,1,0L);
    {
      struct sqla_setd_list sql_setdlist[3];
#line 94 "lobfile1.sqc"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 9;
#line 94 "lobfile1.sqc"
      sql_setdlist[0].sqldata = (void*)database;
#line 94 "lobfile1.sqc"
      sql_setdlist[0].sqlind = 0L;
#line 94 "lobfile1.sqc"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 9;
#line 94 "lobfile1.sqc"
      sql_setdlist[1].sqldata = (void*)userid;
#line 94 "lobfile1.sqc"
      sql_setdlist[1].sqlind = 0L;
#line 94 "lobfile1.sqc"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 19;
#line 94 "lobfile1.sqc"
      sql_setdlist[2].sqldata = (void*)password;
#line 94 "lobfile1.sqc"
      sql_setdlist[2].sqlind = 0L;
#line 94 "lobfile1.sqc"
      sqlasetd(2,0,3,sql_setdlist,0L);
    }
#line 94 "lobfile1.sqc"
  sqlacall((unsigned short)29,5,2,0,0L);
#line 94 "lobfile1.sqc"
  sqlastop(0L);
}

#line 94 "lobfile1.sqc"

   CHECKERR ("CONNECT TO MUSICDB");

   do {
      fflush(stdin);
      printf("\nPlease enter the ARTNO for whom you want the resume. ");
      printf("\n(the only ones that have data are 42 and 68) : \n");
      num_args=fscanf(stdin,"%d",&artno);
   }
   while (num_args != 1);
   
   sprintf(resume.name, "res%d.txt", artno);
   resume.name_length = strlen(resume.name);
   resume.file_options = SQL_FILE_OVERWRITE;

   
/*
EXEC SQL SELECT bio INTO :resume :lobind FROM artists  /- :rk.3:erk. -/
      WHERE artno = :artno ;
*/

{
#line 110 "lobfile1.sqc"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 110 "lobfile1.sqc"
  sqlaaloc(2,1,2,0L);
    {
      struct sqla_setd_list sql_setdlist[1];
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqldata = (void*)&artno;
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqlind = 0L;
#line 110 "lobfile1.sqc"
      sqlasetd(2,0,1,sql_setdlist,0L);
    }
#line 110 "lobfile1.sqc"
  sqlaaloc(3,1,3,0L);
    {
      struct sqla_setd_list sql_setdlist[1];
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqltype = 809; sql_setdlist[0].sqllen = 267;
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqldata = (void*)&resume;
#line 110 "lobfile1.sqc"
      sql_setdlist[0].sqlind = &lobind;
#line 110 "lobfile1.sqc"
      sqlasetd(3,0,1,sql_setdlist,0L);
    }
#line 110 "lobfile1.sqc"
  sqlacall((unsigned short)24,1,2,3,0L);
#line 110 "lobfile1.sqc"
  sqlastop(0L);
}

#line 110 "lobfile1.sqc"


   if (lobind < 0) {
      printf ("NULL LOB indicated \n");
   } else {
      printf ("Resume for ARTNO %d is in file : %s\n", artno, resume.name);
   } /* endif */

   
/*
EXEC SQL CONNECT RESET;
*/

{
#line 118 "lobfile1.sqc"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 118 "lobfile1.sqc"
  sqlacall((unsigned short)29,3,0,0,0L);
#line 118 "lobfile1.sqc"
  sqlastop(0L);
}

#line 118 "lobfile1.sqc"

   CHECKERR ("CONNECT RESET");
   return 0;
}
/* end of program : LOBFILE1.SQC */
