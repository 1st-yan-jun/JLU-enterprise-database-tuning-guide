select tabname, colname, typename 
from syscat.columns 
where tabschema = user 
order by 1,2;
