@if %1''=='' goto help
@echo doing lab 3 using %1 as drive

db2 create db musicdb on %1 dft_extent_sz 16
db2 update db cfg for musicdb using maxappls 40 maxlocks 50 dbheap 960 buffpage 160
db2 update db cfg for musicdb using pckcachesz 400 locklist 40 sortheap 16 stmtheap 512
db2 update db cfg for musicdb using logfilsiz 6 logsecond 18 num_freqvalues 12

db2 connect to musicdb 

db2 create tablespace dms01 managed by database using (file '%1\dms\dms01' 33) extentsize 4

db2 create regular tablespace dms02 managed by database using (file '%1\dms\dms02' 13) extentsize 2
db2 create long tablespace dms03 managed by database using (file '%1\dms\dms03' 721) extentsize 8
db2 create regular tablespace dms04 managed by database using (file '%1\dms\dms04' 21) extentsize 2
db2 create regular tablespace dms05 managed by database using (file '%1\dms\dms05' 15) extentsize 2
db2 create regular tablespace dms06 managed by database using (file '%1\dms\dms06' 37) extentsize 4
db2 create regular tablespace sms01 managed by system using ('%1\sms\sms01','%1\sms\sms02') extentsize 4

db2 connect reset
goto end

:help
@echo Usage    lab3 d:
@echo               where "d:" is the drive where you want the database created
:end