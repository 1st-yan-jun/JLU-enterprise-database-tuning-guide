db2 connect to musicdb
db2 -tvf art_create.ans
db2 -tvf ..\crtables
db2 -tvf ..\grants
db2 connect to musicdb
db2 -tvf ind_create.ans
db2 -tvf view_create.ans
db2 -tvf ..\crview
db2 connect to musicdb
db2 -tvf alias_create.ans
db2 -tvf ri_create.ans
db2 -tvf ..\crri
db2 -tvf chk_create.ans
db2 -tvf trig_create.ans