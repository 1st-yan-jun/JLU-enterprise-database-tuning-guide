@if %1''=='' goto help
@echo creating user inst%1

net user inst%1 inst%1 /add 
net localgroup Administrators inst%1 /add

@echo Now, change the value of DB2INSTANCE in the environment variables to "INST%1"
@echo Then, logoff, and log back on as "inst%1"

@goto end
:help
@echo Usage    lab1a nn
@echo                where 'nn' is the team number you want to work with.
:end
