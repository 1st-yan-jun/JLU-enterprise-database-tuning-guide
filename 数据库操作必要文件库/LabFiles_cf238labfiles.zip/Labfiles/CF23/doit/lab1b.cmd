@if %1''=='' goto help
@echo creating instance inst%1

db2icrt inst%1

net localgroup adm%1 /add

net localgroup adm%1 inst%1 /add
net localgroup adm%1 db2admin /add

@echo Now, shutdown this window.
goto end
:help
@echo Usage  lab1b nn
@echo              where nn is the team number you want to create
:end
