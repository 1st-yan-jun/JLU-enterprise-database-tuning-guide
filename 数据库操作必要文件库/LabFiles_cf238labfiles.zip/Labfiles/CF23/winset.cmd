@echo finalizing Windows setup for hostname %computername%

db2set DB2SYSTEM=%computername%
db2icrt db2 -s ese -u admin,ibm4es -h %computername%
db2 catalog db toolsdb

db2set DB2ACCOUNT=%computername%\db2admin -i
db2set DB2INSTOWNER=%computername% -i
db2set DB2PORTRANGE=60000:60003 -i
db2set DB2NBADAPTERS=6 -i
db2set DB2INSTPROF=D:\SQLLIB -i
db2set DB2COMM=TCPIP -i

db2 update dbm cfg using authentication server spm_name %computername% 
db2 update dbm cfg using svcename db2c_DB2 discover search 
db2 update dbm cfg using discover_inst enable

db2 catalog admin local node %computername% instance db2das00 system %computername% ostype win

db2 update admin cfg using db2system %computername%
db2admin stop
db2admin start
db2start

