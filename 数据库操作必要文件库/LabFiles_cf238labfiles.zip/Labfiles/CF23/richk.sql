select substr(tabname,1,18), parents, children 
from syscat.tables 
where tabschema = user 
order by tabname;
